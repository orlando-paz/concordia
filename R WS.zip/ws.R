funcAvg <- function(vect)
{
  if(mean(vect) < 3)
    return('low')
  else if (mean(vect) >= 3 && mean(vect) < 9)
    return("medium")
}


count <- function(vect)
{
  length(which(vect > 3))
}

funcAvg2 <- function(vect)
{
  if(mean(vect) < 3)
    return('low')
  else if (mean(vect) >= 3 && mean(vect) < 9)
    return("medium")
}

count2 <- function(vect)
{
  length(which(apply(vect, 1, mean) > 3))
}

caseControl <- function(vect, control)
{
  result = 0;
  for (i in 1:length(vect))
  {
    if(control[i] == "case")
      result = result + vect[i]
    else
      result = result - vect[i]
  }
  
  return (result)
}

mean <- function(vect)
{
  return (apply(vect))
}
